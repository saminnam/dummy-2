import React from "react";
import GlobalTitle from "../../components/Global/GlobalTitle";
import Team from "./Team";

const About = () => {
  return (
    <>
      <GlobalTitle title={"About Us"} />
      <Team/>
    </>
  );
};

export default About;
