import React from "react";
import GlobalTitle from "../../components/Global/GlobalTitle";

const Projects = () => {
  return (
    <>
      <GlobalTitle title={"Our Projects"} />
    </>
  );
};

export default Projects;
