import React from "react";

const OurService = () => {
  return (
    <section className="py-10 overflow-hidden bg-white sm:py-16 lg:py-24">
      <div className="px-4 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <div className="grid items-center grid-cols-1 lg:grid-cols-2 gap-x-12 xl:gap-x-24 gap-y-12">
          <div className="relative lg:mb-12">
            <img
              className="absolute -right-0 -bottom-8 xl:-bottom-12 xl:-right-4"
              src="https://cdn.rareblocks.xyz/collection/celebration/images/content/3/dots-pattern.svg"
              alt="pattern"
              loading="lazy"
              data-aos="fade-up-right"
            />
            <div className="pl-12 pr-6 h-[450px]">
              <img
                className="relative rounded w-full h-full"
                src="https://cdn.pixabay.com/photo/2019/02/06/16/32/architect-3979490_640.jpg"
                alt="img"
                loading="lazy"
                data-aos="fade-up-left"
              />
            </div>
          </div>
          <div className="2xl:pl-16">
            <div className="flex flex-col gap-3 lg:items-start items-center justify-center md:mb-10">
              <h2
                className="lg:text-6xl text-4xl title-font"
                data-aos="fade-down"
              >
                Eshwar Construction
              </h2>
              <div className="h-[4px] w-[100px] bg-amber-950 rounded"></div>
            </div>
            <p className="text-xl leading-relaxed text-gray-500 mt-9" data-aos="zoom-in-up">
              At Eshwaran Construction, we believe in building more than just
              structure we create homes, workplaces, and spaces that stand the
              test of time. With a commitment to quality, innovation, and
              customer satisfaction, we ensure every project is a seamless
              experience from start to finish.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OurService;
