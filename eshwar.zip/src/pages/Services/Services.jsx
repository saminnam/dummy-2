import React from "react";
import GlobalTitle from "../../components/Global/GlobalTitle";
import OurService from "./OurService";
import OurExpertise from "./OurExpertise";

const Services = () => {
  return (
    <>
      <GlobalTitle title={"Our Services"} />
      <OurService />
      <OurExpertise />
    </>
  );
};

export default Services;
