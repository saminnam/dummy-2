import React from "react";
import "./AboutUs.css";

const AboutUs = () => {
  return (
    <section className="bg-AboutUs overflow-hidden md:py-20 py-10 my-10 md:px-10 px-5">
      <div className="container mx-auto">
        <div className="flex flex-col gap-3 items-center justify-center md:mb-15  mb-10">
          <h2 className="lg:text-6xl text-4xl title-font" data-aos="fade-down">What We Do ?</h2>
          <div className="h-[4px] w-[100px] bg-amber-950 rounded"></div>
        </div>
        <div class="lg:relative flex flex-col items-center mx-auto lg:flex-row-reverse lg:max-w-5xl lg:mt-12 xl:max-w-6xl">
          <div class="w-full h-64 lg:w-1/2 lg:h-[550px]" data-aos="fade-left">
            <img
              class="h-full w-full object-cover"
              src="https://www.shutterstock.com/image-photo/construction-worker-yellow-hard-hat-260nw-2518265201.jpg"
              alt="construction"
              loading="lazy"
            />
          </div>
          <div class="max-w-lg bg-white md:max-w-2xl md:z-10 md:shadow-lg lg:absolute lg:top-0 md:mt-5 lg:w-3/5 lg:left-0 lg:mt-20 lg:ml-20 xl:mt-24 xl:ml-12" data-aos="fade-right">
            <div class="flex flex-col p-12 md:px-16" >
              <h2 class="font-serif text-2xl font-medium uppercase text-green-600 lg:text-4xl" data-aos="fade-down-right">
                Mission
              </h2>
              <p class="mt-4 text-lg text-gray-500">
                Our vision is to make dream living spaces a reality for every
                budget. With passion and dedication, we guide our clients from
                design finalization to the flawless completion of their dream
                home or space, ensuring every detail meets their expectations.
              </p>
              <div class="mt-8">
                <button className="px-7 cursor-pointer py-3 bg-green-600 text-white hover:text-green-600 transition-all duration-300 hover:bg-transparent border-green-600 border rounded">
                  Know More
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="lg:relative flex flex-col md:gap-5 lg:gap-0 items-center mx-auto lg:flex-row lg:max-w-5xl lg:mt-12 xl:max-w-6xl">
          <div class="max-w-lg bg-white md:max-w-2xl md:z-10 md:shadow-lg lg:absolute lg:top-0 md:mt-5 lg:w-3/5 lg:right-0 lg:mt-20 lg:ml-20 xl:mt-24 xl:ml-12" data-aos="fade-left">
            <div class="flex flex-col p-12 md:px-16">
              <h2 class="font-serif text-2xl font-medium uppercase text-green-600 lg:text-4xl" data-aos="fade-down-left">
                Vision
              </h2>
              <p class="mt-4 text-gray-500 text-lg">
                Within the next five years, our vision is to make dream homes a
                reality for every budget, creating spaces that blend quality,
                comfort, and individuality. We are committed to guiding our
                clients through every step of the journey from the first design
                sketch to the final finishing touch with a deep understanding of
                their aspirations.
              </p>
              <div class="mt-8">
                <button className="px-7 cursor-pointer py-3 bg-green-600 text-white hover:text-green-600 transition-all duration-300 hover:bg-transparent border-green-600 border rounded">
                  Know More
                </button>
              </div>
            </div>
          </div>
          <div class="w-full h-64 lg:w-1/2 lg:h-[550px]" data-aos="fade-right">
            <img
              class="h-full w-full object-cover"
              src="https://d3njjcbhbojbot.cloudfront.net/api/utilities/v1/imageproxy/https://images.ctfassets.net/wp1lcwdav1p1/3mxES9n4fCtrwNXYqyWKaS/821300a9bf5008fb17efaac62563c9ee/Construction-workers-and-architect-looking-at-blueprints-on-construction-site-514311930_5413x3609.jpeg?w=1500&h=680&q=60&fit=fill&f=faces&fm=jpg&fl=progressive&auto=format%2Ccompress&dpr=1&w=1000"
              alt="construction"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
